# __init__.py
from .emotion_image import EmotionImage

__all__ = ['EmotionImage']
